public class Main{

    public static void main(String[] args) {
        
        Cliente cliente;
        cliente = new Cliente("Renan", "123", "18/06/2003", "Vai corintia", 19);
        System.out.println(cliente.toString());
    }

}